---
name: Synchronous Local-First Editorial System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464554'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#767586'
  outline-variant: '#c7c4d7'
  surface-tint: '#494bd6'
  primary: '#4648d4'
  on-primary: '#ffffff'
  primary-container: '#6063ee'
  on-primary-container: '#fffbff'
  inverse-primary: '#c0c1ff'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#904900'
  on-tertiary: '#ffffff'
  tertiary-container: '#b55d00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#ffdcc5'
  tertiary-fixed-dim: '#ffb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#703700'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  2xl: 64px
  container-max: 1200px
  sidebar-width: 280px
  gutter: 24px
---

## Brand & Style

The design system is engineered for a high-performance, local-first collaborative environment. The brand personality balances the approachable utility of a modern workspace with the precision of developer-centric tools. It draws inspiration from **Minimalism** and **Corporate/Modern** aesthetics, focusing on intentionality, speed, and focus.

The visual narrative prioritizes content over chrome. By utilizing generous whitespace and a "content-first" hierarchy, the system ensures that the user's data remains the primary focal point. Interactions should feel instantaneous and reliable, evoking an emotional response of clarity and professional mastery.

## Colors

The palette is anchored by a vibrant **Indigo** accent, used sparingly to indicate action and primary states. The neutral scale is deep and expansive, utilizing slate-toned grays to provide a sophisticated backdrop that works harmoniously in both light and dark modes.

- **Primary Indigo:** Used for active states, primary buttons, and cursor indicators.
- **Surface Strategy:** Layers are built using incremental shifts in the neutral scale rather than heavy borders.
- **Accessibility:** Text-on-background contrast ratios must exceed 4.5:1 for body text and 3:1 for large display text.
- **Dark Mode:** Transition to a "Midnight" palette using `#020617` as the foundation to maintain depth and reduce eye strain during long writing sessions.

## Typography

The typography system relies on **Inter** for its exceptional legibility and systematic feel. For technical data and code blocks, **JetBrains Mono** is introduced to provide a clear distinction between prose and logic.

Hierarchy is established through weight and whitespace rather than excessive size shifts. Large display titles use a tight letter-spacing to feel "locked" and authoritative. Body text uses a generous line height (1.6) to facilitate deep reading and minimize cognitive load.

## Layout & Spacing

This design system utilizes a **Fluid Grid** with fixed-width constraints for the main editorial area to ensure optimal line lengths (60-80 characters). 

- **The 4px Rhythm:** All spacing tokens are multiples of 4, ensuring a consistent vertical rhythm.
- **Desktop:** A 12-column grid with 24px gutters. The primary sidebar is fixed at 280px, while the content area fluidly expands up to a 1200px max-width.
- **Mobile:** Transition to a single-column layout with 16px horizontal margins. Sidebars transition to off-canvas drawers.
- **Editorial Focus:** Increase padding around the main text container (`xl` or `2xl`) to create a "Zen" writing environment.

## Elevation & Depth

Depth is communicated through **Tonal Layers** and **Ambient Shadows**. Instead of harsh outlines, the system uses subtle shifts in background color to define boundaries, supplemented by soft, multi-layered shadows for floating elements.

- **Level 0 (Base):** The main canvas background.
- **Level 1 (Card/Surface):** A subtle 1px border (`#e2e8f0`) with no shadow.
- **Level 2 (Dropdown/Popover):** A soft, diffused shadow: `0 4px 12px rgba(0,0,0,0.05)`.
- **Level 3 (Modals/Floating Toolbars):** A multi-stage shadow for maximum lift: `0 12px 32px rgba(0,0,0,0.1), 0 2px 8px rgba(0,0,0,0.05)`.
- **Glassmorphism:** Use a `12px` backdrop blur for floating toolbars and sidebars to maintain context of the underlying content.

## Shapes

The shape language is sophisticated and "Apple-like," utilizing a **Rounded** approach. 

- **Standard Elements:** Buttons and input fields use a `0.5rem` (8px) radius.
- **Containers:** Premium cards and main content areas use a `1rem` (16px) radius to feel approachable yet structured.
- **Avatars:** Always circular to contrast against the geometric grid of the document.
- **Toolbars:** Use `rounded-xl` or fully pill-shaped configurations to denote their "floating" nature.

## Components

### Buttons
- **Primary:** Solid Indigo gradient (`#6366f1` to `#4f46e5`). White text. Subtle 1px inner highlight on top edge.
- **Secondary:** Surface-colored background with a subtle border. Indigo text.
- **Ghost:** No background or border until hover. Used for navigation and low-emphasis actions.

### Premium Cards
- Background: `surface`.
- Border: 1px solid `border`.
- Corner Radius: 16px.
- Hover State: Lift effect using Level 2 elevation and a primary-colored accent border (2px).

### Navigation Sidebar
- Background: `surface` (light) or `muted` (dark).
- Typography: `label-md`. 
- Active State: Soft indigo background tint (10% opacity) with a 3px vertical "pill" indicator on the left.

### Floating Toolbars
- Background: Semi-transparent `popover` with `12px` backdrop blur.
- Shadow: Level 3.
- Layout: Horizontal flex with `sm` spacing between icons.

### Avatars
- Size: 32px (standard), 24px (compact).
- Styling: Circular with a 2px white border when stacked in collaborative groups.

### Input Fields
- Style: Minimalist. 1px border that turns Indigo on focus. 
- Shadow: Subtle inner shadow to give a slight "set-in" feel.